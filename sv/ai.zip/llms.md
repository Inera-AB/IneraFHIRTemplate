# inera.core.template#2.2.2: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Förväntade svar](expected-responses.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Användningsfall](use-cases.md)
* [CapabilityStatement](capabilitystatement.md)
* [Mappning till profiler](mappings.md)
* [Informationsunderlag](information-basis.md)
* [Versionshistorik](version-history.md)
* [Om](about.md)
* [Nedladdningar](downloads.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Felhantering](error-handling.md)
* [Inledning](introduction.md)
* [Säkerhet och behörighet](security.md)
* [Testning och validering](testing.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
