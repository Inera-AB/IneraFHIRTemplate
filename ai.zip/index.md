# Hem - Inera FHIR Implementation Guide Template v2.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ig/template/ImplementationGuide/inera.core.template | *Version*:2.1.0 |
| Draft as of 2026-07-14 | *Computable Name*:IneraCoreTemplate |

# Hem

### [Domännamn]

**Ange namnet på den avgränsade förmåga som denna IG realiserar, t.ex. "Fasta kontakter" eller "Remisser" — inte ett brett kliniskt område som "Läkemedel". En förmåga ska vara tillräckligt avgränsad för att kunna implementeras i sin helhet av denna IG. Om ert verksamhetsområde är stort, dela upp det i flera IG:er per avgränsad förmåga och länka mellan dem vid behov.**

**Förklara varför förmågan är viktig inom svensk hälso- och sjukvård, vilken roll den spelar i patientvård eller informationsutbyte, och varför den prioriterats för FHIR-standardisering.**

-------

### Omfattning

**Definiera vad denna IG täcker och vad den inte täcker. Specificera vilka typer av användningsfall, kliniska scenarier eller informationsutbyten som ingår. Nämn eventuella explicita avgränsningar. Om denna IG är avsedd att användas som bas för mer specialiserade guider, säg det här. Exempel: "Denna IG gäller för X inom ramen för Y. Den täcker inte Z. Härledda guider kan begränsa eller utöka omfattningen vid behov."**

-------

### Syfte

**Beskriv målet med denna IG. Förklara vilket problem den löser och hur den passar in i det bredare Inera- och e-hälsolandskapet. Hänvisa till nationella eller regionala program, standarder eller mandat som motiverat arbetet.**

-------

### Målgrupp

**Ange vem denna IG riktar sig till, t.ex. implementatörer, systemleverantörer, vårdgivare och/eller förvaltningsorganisationer. Beskriv vilken bakgrundskunskap läsaren förväntas ha (t.ex. grundläggande FHIR-kunskap) och hänvisa till [Inledning](introduction.md) och Implementering (se t.ex. [REST-interaktioner och sökparametrar](rest-interactions.md)) för den som ska bygga mot IG:n.**

-------

### Terminologi

På [Inera Terminologitjänst](https://www.inera.se/tjanster/alla-tjanster-a-o/terminologitjanst-for-nationell-e-halsa/) finns alla refererade kodsystem och värdemängder som utvecklats av Inera.

-------

### Beroenden

Denna IG har ett beroende till SE-core, definierat av HL7 Sweden. Detta återspeglas i de profiler som ärver från SECore-profiler.

-------

### Dokumentation

Mer information om FHIR på Inera finns [här](https://fhir.inera.se/). FHIR på Inera är en del av RIVTA – referensarkitekturen för svensk hälso- och sjukvård.

Information om hur denna IG förvaltas finns under [Om](about.md).

-------

### Om mallens struktur

Menyn i denna IG är medvetet utformad efter samma mönster som europeiska specifikationer, t.ex. FHIR ePS (Hem / Inledning / Funktionellt / Implementering / Om / Artefakter), för att ge implementatörer en igenkännbar ingång oavsett vilken europeisk FHIR-IG de arbetar med.

Informationsmodellen för denna förmåga publiceras externt och fristående i en egen informationsspecifikation (se [Informationsunderlag](information-basis.md) under Funktionellt) snarare än i denna IG. Det håller informationsspecifikationen som den auktoritativa källan för begrepp och informationsstruktur, och undviker att IG:n och specifikationen glider isär över tid.

