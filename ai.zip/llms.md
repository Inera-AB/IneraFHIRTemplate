# inera.core.template#2.1.0: Inera FHIR Implementation Guide Template

## Pages

* [Hem](index.md)
* [Användningsfall](use-cases.md)
* [CapabilityStatement](capabilitystatement.md)
* [Nedladdningar](downloads.md)
* [Mappning till profiler](mappings.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Testning och validering](testing.md)
* [Artifacts Summary](artifacts.md)
* [Felhantering](error-handling.md)
* [Om](about.md)
* [Inledning](introduction.md)
* [Förväntade svar](expected-responses.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Informationsunderlag](information-basis.md)
* [Säkerhet och behörighet](security.md)
* [Versionshistorik](version-history.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](index.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
