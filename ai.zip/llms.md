# inera.core.template#2.0.0: Inera FHIR Implementation Guide Template

## Pages

* [Hem](index.md)
* [CapabilityStatement](capabilitystatement.md)
* [Funktionellt](functional.md)
* [Nedladdningar](downloads.md)
* [Mappning till profiler](mappings.md)
* [Testning och validering](testing.md)
* [Profiler](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Felhantering](error-handling.md)
* [Terminologi](terminology.md)
* [Om](about.md)
* [Exempel](examples.md)
* [Introduktion](introduction.md)
* [Förväntade svar](expected-responses.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Säkerhet och behörighet](security.md)
* [Versionshistorik](version-history.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](index.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
