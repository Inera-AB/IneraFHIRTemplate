# inera.core.template#2.2.2: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Användningsfall](use-cases.md)
* [Om](about.md)
* [Testning och validering](testing.md)
* [Felhantering](error-handling.md)
* [Inledning](introduction.md)
* [Mappning till profiler](mappings.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Förväntade svar](expected-responses.md)
* [Nedladdningar](downloads.md)
* [CapabilityStatement](capabilitystatement.md)
* [Säkerhet och behörighet](security.md)
* [Versionshistorik](version-history.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Roller och ansvar](roles-and-responsibilities.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
